##############################################################################
#########                          PASPE 2021                        #########
#########      Analisis de datos de Ciencias Genomicas usando R      #########   
#########    E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)     #########
#########                    Bitacora de comandos                    #########
#########                     UNIDAD 3. METAGENOMICA                 #########
#########                Sesion 7 y 8. Heatmaps y boxplot            #########
##############################################################################

# Texto sin acentos

# Posicionarme en mi espacio de trabajo
getwd()
setwd("~/Desktop/PASPE_2020_Datos_genomicos_R/4.Metagenomica_heatmaps_boxplots")
dir()

### Cargar las librerias de trabajo
suppressMessages(library(gplots))
library(ggplot2)
library(vegan)
library(reshape2)
library(metagenomeSeq)
library(Heatplus)
library(RColorBrewer)

#### leer los datos

tabla <- t(read.delim("tablas/percent_Class_more_1_perc.txt", 
                      header=T, row.names=1))
dim(tabla)

head(tabla)
### Ejercicio 1. heatmap basico

colors <- colorRampPalette(c("lightyellow", "dodgerblue"), space="rgb")(100)
length(colors)
head(colors)

heatmap(tabla, Rowv=NA, Colv= NA, col= colors, margins= c(10,2))

### Ejercicio 2. agrupaciones jerarquicas

mat_dist <- vegdist(tabla, method="bray")

row.clus <- hclust(mat_dist, "aver")
heatmap(tabla, Rowv=as.dendrogram(row.clus), 
        Colv= NA, col= colors, margins= c(10,3))

mat_dist_class <-vegdist(t(tabla), method = "bray") 
col.clus <- hclust(mat_dist_class, "aver")

png("figuras/heatmap_class_basico.png", width = 300*10, height = 300*6, units = "px", res=300)
heatmap(tabla, Rowv=as.dendrogram(row.clus), 
        Colv= as.dendrogram(col.clus), col= colors, margins= c(12,3))
dev.off()

##### Ejercicio 3. Identificar cluster

head(tabla)
muestras <- data.frame(nombre=rownames(tabla))
head(muestras)
muestras
muestras$clase <- sapply(as.character(muestras$nombre), function(x){strsplit(x, "_")[[1]][1]})

muestras$color <- "coral1"
muestras$color[which(muestras$clase=="Someras")] <- "seagreen2"
muestras$color[which(muestras$clase=="Profundas")] <- "deepskyblue"

heatmap.2(tabla, Rowv = as.dendrogram(row.clus), Colv=as.dendrogram(col.clus),
          col=colors, RowSideColors=muestras$color, margins=c(6,3))

dev.off()


png("figuras/heatmap_class_complejo.png", width = 300*10, height = 300*6, units = "px", res=300)
heatmap.2(tabla, Rowv = as.dendrogram(row.clus), Colv=as.dendrogram(col.clus),
          col=colors, RowSideColors=muestras$color, margins=c(13,10),
          trace="none", density.info = "none", xlab="Clase", ylab="Muestras",
          main="Heatmap a nivel de Clase", lhei = c(2,8))
legend("bottomleft", c("Costa", "Profundas", "Someras"), 
       fill=c("coral1", "deepskyblue", "seagreen2"))
dev.off()

#### Ejercicio 4. Agregar anotaciones de otras variables

variables <- read.delim("tablas/abiotic_variables.txt", header=T, row.names=1)
head(variables)

var_interes <- c("Naphthalene", "Fluorene", "Organic_Matter")
subtabla <- variables[,which(colnames(variables)%in% var_interes)]
head(subtabla)

head(muestras)
muestras$estacion <- sapply(as.character(muestras$nombre), function(x){strsplit(x, "_")[[1]][2]})
muestras$clase2 <- sapply(as.character(muestras$nombre), function(x){strsplit(x, "")[[1]][1]})
muestras$clase3 <- paste(muestras$clase2, muestras$estacion, sep=".")

head(tabla)
rownames(tabla) <- muestras$clase3

colors <- colorRampPalette(c("lightyellow", "dodgerblue"), space="rgb")(40)

plot(annHeatmap2(tabla, col=colors, breaks = 50, 
                 dendrogram = list(Row = list(dendro = as.dendrogram(row.clus)), Col = list(dendro = as.dendrogram(col.clus))),
                 legend=3, labels=list(Col=list(nrow=12)),
                 ann=list(Row=list(data=subtabla)),
                 cluster = list(Row=list(cuth=0.25, col=c("seagreen2", "deepskyblue", "coral1")))))
dev.off()


png("figuras/heatmap_class_variables.png", width = 300*10, height = 300*6, units = "px", res=300)
plot(annHeatmap2(tabla, col = colors, breaks = 50,
                 dendrogram = list(Row = list(dendro = as.dendrogram(row.clus)), Col = list(dendro = as.dendrogram(col.clus))),
                 legend = 3, labels = list(Col = list(nrow = 12)), 
                 ann = list(Row = list(data = subtabla)),
                 cluster = list(Row = list(cuth = 0.25, col = c("seagreen2", "deepskyblue", "coral1")))))
dev.off()

####################
####  BOXPLOTS  ####
####################

getwd()
setwd("~/Desktop/PASPE_2020_Datos_genomicos_R/4.Metagenomica_heatmaps_boxplots")

suppressMessages(library(gplots))
suppressMessages(library(ggplot2))
suppressMessages(library(vegan))
suppressMessages(library(reshape2))
suppressMessages(library(metagenomeSeq))
suppressMessages(library(Heatplus))
suppressMessages(library(RColorBrewer))
sessionInfo()

tabla <- t(read.delim("tablas/percent_Class_more_1_perc.txt", header=T, row.names = 1))
head(tabla)
dim(tabla)

taxas <- c("Acidimicrobiia", "Betaproteobacteria", "Clostridia", "Planctomycetia")

new_tabla <- tabla[,which(colnames(tabla)%in% taxas)]
head(new_tabla)

dim(new_tabla)

melt_tabla <- melt(new_tabla)
head(melt_tabla)

melt_tabla$clase <- sapply(as.character(melt_tabla$Var1), function(x){strsplit(x, "_")[[1]][1]})  

ggplot(data=melt_tabla, aes(x=Var2, y=value, fill=clase)) +
        geom_boxplot()

ggplot(data=melt_tabla, aes(x=Var2, y=value, fill=clase)) +
        geom_boxplot() +
        scale_fill_manual(values=c("coral1", "deepskyblue", "seagreen2"))+
        labs(title= "Boxplots at Class level", y= "Relative frequency (%)", x="", fill="Samples") +
        theme_bw()


png("figuras/boxplot_class.png", width = 300*10, height = 300*6, units = "px", res=300)
ggplot(data=melt_tabla, aes(x=Var2, y=value, fill=clase)) +
        geom_boxplot() +
        scale_fill_manual(values=c("coral1", "deepskyblue", "seagreen2"))+
        labs(title= "Boxplots at Class level", y= "Relative frequency (%)", x="", fill="Samples") +
        theme_bw()
dev.off()

