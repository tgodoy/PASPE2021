##############################################################################
#########                          PASPE 2021                        #########
#########      Analisis de datos de Ciencias Genomicas usando R      #########   
#########    E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)     #########
#########                    Bitacora de comandos                    #########
#########                     UNIDAD 3. METAGENOMICA                 #########
#########                         Graficos extras                    #########
##############################################################################

# Texto sin acentos

# Cargar librerias de trabajo
library(ggplot2)
library(vegan)
library(grid)
library(reshape2)
library(metagenomeSeq)

###### Graficas de burbujas con las abundancias relativas ######

# Cargar datos 
rel_abund <- read.delim("tablas/percent_Genus.txt", header=T, row.names=1)
View(rel_abund)

muestras <- data.frame(estacion=colnames(rel_abund))
View(muestras)
muestras$clase <- sapply(as.character(muestras$estacion), function(x){strsplit(x, "_")[[1]][1]})
muestras$color <- "coral1"
muestras$color[which(muestras$clase=="Someras")] <- "seagreen2"
muestras$color[which(muestras$clase=="Profundas")] <- "deepskyblue"

# Obtener los generos mas abundantes
# Determinar la media de abundancia relativa para cada Taxa (fila)
maxab <- apply(rel_abund, 1, mean)
head(maxab)

## Determinar un corte de abundancia
# 3%
cut <- 3

#### Realizar el punto de corte a la matriz
# Obtener los taxa que tienen una abundancia mayor al corte que estamos poniendo
n1 <- names(which(maxab > cut))
n1_mean <- maxab[which(maxab > cut)]

# Numero de taxas con los que nos quedaremos
length(n1)

# Generar matriz con el corte 
subtable <- rel_abund[which(rownames(rel_abund) %in% n1),]
View(subtable)

# Ordenar la matrix de acuerdo a la media de abundancia relativa de mayor a menor
orden <- names(sort(n1_mean, decreasing = T))

# Generar una nueva matriz, ya ordenada
new <- matrix(nrow=dim(subtable)[1], ncol=dim(subtable)[2])
colnames(new) <- colnames(subtable)
rownames(new) <- orden

#fill new matrix
for (i in 1:dim(new)[2]){
  numCol <- which(colnames(subtable)==colnames(new)[i])
  for (j in 1:dim(new)[1]){
    numRow <- which(rownames(subtable)==rownames(new)[j])
    new[j,i] <- subtable[numRow, numCol]
  }
}

View(new)

melt_new <- melt(new)
View(melt_new)
class(melt_new$Var1)

# generamos el vector de colores aleatorios
color = grDevices::colors()[grep('gr(a|e)y', grDevices::colors(), invert = T)]
my_color <- sample(color, dim(subtable)[1], replace=FALSE)
gradiente <- colorRampPalette(c("coral1", "seagreen2", "deepskyblue"), space="rgb")(3)

# generar el grafico
ggplot(melt_new, aes(y=Var1, x=Var2, size=value)) + 
  geom_point(shape=16, alpha=0.8, aes(color=Var1)) + 
  theme_bw(base_size = 7) + 
  theme(panel.grid.major=element_blank(), panel.grid.minor=element_blank(), legend.position = "bottom", legend.box = "vertical", legend.text=element_text(size=6), axis.text.x=element_text(angle=45, hjust=1, vjust=1, size=4), legend.key.size = unit(0.5, "cm"), legend.title=element_blank()) + 
  scale_color_manual(values=my_color) + 
  labs(x = "", y = "", size="Relative abundance", fill="") + 
  scale_size(range = c(0, 8)) + 
  scale_fill_continuous(guide = guide_legend(title.position = "top")) + 
  guides(col = guide_legend(reverse = TRUE)) +
  geom_vline(xintercept=c(5.5, 10.5), linetype="dotted", color="gray50")

# guardar imagen
png("figuras/bubbles_genus.png", width = 300*10, height = 300*6, units = "px", res=300)
ggplot(melt_new, aes(y=Var1, x=Var2, size=value)) + 
  geom_point(shape=16, alpha=0.8, aes(color=Var1)) + 
  theme_bw(base_size = 10) + 
  theme(panel.grid.major=element_blank(), panel.grid.minor=element_blank(), legend.position = "bottom", legend.box = "vertical", legend.text=element_text(size=6), axis.text.x=element_text(angle=45, hjust=1, vjust=1, size=4), legend.key.size = unit(0.5, "cm"), legend.title=element_blank()) + 
  scale_color_manual(values=my_color) + 
  labs(x = "", y = "", size="Relative abundance", fill="") + 
  scale_size(range = c(0, 8)) + 
  scale_fill_continuous(guide = guide_legend(title.position = "top")) + 
  guides(col = guide_legend(reverse = TRUE)) +
  geom_vline(xintercept=c(5.5, 10.5), linetype="dotted", color="gray50")
dev.off()

###### Numero de taxas compartidos ###### 
######       Diagramas de Venn     ###### 

# cargar librerias
library(limma)

# Generar una matriz de ausencia (valor=0) presencia (valor=1)
# Generar una matriz de solo 3 columnas (condiciones)
View(rel_abund)
muestras

matriz_AP <- matrix(ncol=3, nrow=dim(rel_abund)[1])
colnames(matriz_AP) <- c("Costa", "Someras", "Profundas")
rownames(matriz_AP) <- rownames(rel_abund)
View(matriz_AP)

for (i in 1:dim(matriz_AP)[2]){
  clase <- colnames(matriz_AP)[i]
  nums <- which(muestras$clase==clase)
  for (j in 1:dim(matriz_AP)[1]){
    if (sum(rel_abund[j,nums])>0){
      matriz_AP[j,i] <- 1
    } else {
      matriz_AP[j,i] <- 0
    }
  }
}

## Generar el diagrama de Venn con la libreria Limma

vennDiagram(vennCounts(matriz_AP), 
            circle.col=c("coral1", "seagreen2", "deepskyblue"), cex=c(1,1,1))

png("figuras/venn_diagram_genus.png", width = 300*10, height = 300*6, units = "px", res=300)
vennDiagram(vennCounts(matriz_AP), 
            circle.col=c("coral1", "seagreen2", "deepskyblue"), cex=c(1,1,1))
dev.off()


###### library qiime2R ###### 
# Cargar librerias de trabajo
library(qiime2R)
library(tidyverse)
library(phyloseq)

# Leer el "artifac" que genero QIIME2 (table.qza)
tabla_qza <- read_qza("qiime2/table.qza")

# Visualizar la estructura de nuestro objeto
str(tabla_qza)
class(tabla_qza)

# Extraer la informacion del objeto tabla_qza como una lista
names(tabla_qza)

# Acceder a la informacion de las features (ASVs)
View(tabla_qza$data)
head(tabla_qza$data)

# Asociar la taxonomia
taxonomia_qza <- read_qza("qiime2/taxonomy_blast.qza")
str(taxonomia_qza)
class(taxonomia_qza)

# Acceder a la taxonomia
View(taxonomia_qza$data)

# Dividir en niveles taxonomicos la taxonomia usando parse_taxonomy()
taxa_sep <- parse_taxonomy(taxonomia_qza$data)
View(taxa_sep)

# Comprimir data.frame a un nivel taxonomico en particular (Clase)
class_table <- summarize_taxa(tabla_qza$data, taxa_sep)$Class

View(class_table)

# Grafica de barras apilada y heatmaps usando la informacion de metadata
# Cargar el archivo de metadata.tsv
metadata <- read_q2metadata("qiime2/metadata.tsv")
View(metadata)

taxa_barplot(class_table, metadata,"Zone")
taxa_heatmap(class_table, metadata,"Type")

# Guardar imagen en png
png("figuras/taxa_heatmap_physeq.png", width = 10*300, height = 8*300, res = 300, pointsize = 8)
taxa_heatmap(class_table, metadata,"Type")
dev.off()

# Generacion de un archivo de tipo phyloseq
physeq_qiime2 <- qza_to_phyloseq (
  features="qiime2/table.qza",
  tree="qiime2/rooted-tree.qza",
  taxonomy="qiime2/taxonomy_blast.qza",
  metadata = "qiime2/metadata.tsv")

physeq_qiime2
class(physeq_qiime2)
str(physeq_qiime2)

# Generacion del PCoA con el metodo de Bray-Curtis
ordination <- ordinate(physeq_qiime2, "PCoA", "bray")
plot_ordination(physeq_qiime2, ordination, color="Type") + 
  stat_ellipse() +
  scale_color_manual(values= c("deeppink1", "darkturquoise", "gold")) +
  labs(title="PCoA") + theme_bw()


# Generacion del PCoA con el metodo de weighted unifrac
ordination <- ordinate(physeq_qiime2, "PCoA", "wunifrac")
plot_ordination(physeq_qiime2, ordination, color="Type") +
  stat_ellipse() +
  scale_color_manual(values= c("deeppink1", "darkturquoise", "gold")) +
  labs(title="PCoA") + theme_bw()

## Listar objetos generados
ls()

## Informacion de la sesion
sessionInfo()

