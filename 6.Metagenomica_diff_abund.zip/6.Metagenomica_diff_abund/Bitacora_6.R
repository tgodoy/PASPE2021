##############################################################################
#########                          PASPE 2021                        #########
#########      Analisis de datos de Ciencias Genomicas usando R      #########   
#########    E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)     #########
#########                    Bitacora de comandos                    #########
#########                     UNIDAD 3. METAGENOMICA                 #########
#########                Analisis de abundancia diferencial          #########
##############################################################################

# Texto sin acentos

# Cargar librerias de trabajo

library(ggplot2)
library(metagenomeSeq)
library(RColorBrewer)
library(gtools)

### Posicionarme en mi espacio de trabajo
getwd()
setwd("~/Desktop/PASPE_2020_Datos_genomicos_R/6.Metagenomica_diff_abund")

# Cargar datos para la sesion
matriz <- read.delim("tablas/Genus.txt", header=T, row.names=1)

muestras <- data.frame(nombre=colnames(matriz))
muestras$clase <- sapply(as.character(muestras$nombre), function(x){strsplit(x, "_")[[1]][1]})
head(muestras)

summary(as.factor(muestras$clase))

#### Generar la comparacion pareada de los generos diferencialmente abundantes de cada una de los grupos que tenemos
# Generar un directorio especial para que guarde toda la informacion de las permutaciones
# Podemos generarlo con la funcion de system o desde nuestra ventana de Rstudio
#system("mkdir tablas/diff_abund")

# Cambiarnos de directorio
setwd("tablas/diff_abund")
getwd()

grupos <- unique(muestras$clase)

for (i in 1:length(grupos)){
	clase <- unique(muestras$clase)[i]
	num_clase <- i
	samples2keep1 <- which(muestras$clase==clase)
	print(paste("Comenzare con las permutaciones de ", clase, sep=""))
	for (j in 1:(length(unique(muestras$clase))-1)){
		clases <- which(!unique(muestras$clase)==clase)
		num_clase_en_turno <- clases[j]
		clase_en_turno <- unique(muestras$clase)[num_clase_en_turno]
		samples2keep2 <- which(muestras$clase== clase_en_turno)
		lista <- muestras$nombre[c(samples2keep1, samples2keep2)]
		nombres_corta <- muestras[c(samples2keep1, samples2keep2),]
		write.table(nombres_corta, paste(clase,"_", clase_en_turno,"_metadata.txt", sep=""), quote=F, col.names=T, row.names=F, sep="\t")
		clean_matriz <- matriz[,c(samples2keep1, samples2keep2)]
		num <- which(rowSums(clean_matriz)==0)
		if (length(num)==0){
			clean_matriz <- matriz[,c(samples2keep1, samples2keep2)]
			} else{
				clean_matriz <- matriz[-num,c(samples2keep1, samples2keep2)]
				}
		exportMat(as.matrix(clean_matriz),file =paste(clase,"_", clase_en_turno,"_filtered_OTUS_matrix.txt", sep=""))
		mydata<-loadMeta(paste(clase,"_", clase_en_turno,"_filtered_OTUS_matrix.txt", sep=""))
		obj <-  newMRexperiment(mydata$counts)
		p <-  cumNormStatFast(obj)
		normalized_matrix <-  cumNormMat(obj, p = p)
		exportMat(normalized_matrix, file =paste(clase,"_", clase_en_turno,"_normal_filtered_otu_table.txt", sep=""))
		mydata<-loadMeta(paste(clase,"_", clase_en_turno,"_normal_filtered_otu_table.txt", sep=""))
		mymetadata<-loadPhenoData(paste(clase,"_", clase_en_turno,"_metadata.txt", sep=""), tran = TRUE, sep = "\t")
		phenotypeData <- AnnotatedDataFrame(mymetadata)
		MRexp <- newMRexperiment(mydata$counts, phenoData=phenotypeData)
		length_clase <-length(samples2keep1)
		length_clase_en_curso <- length(samples2keep2)
		cut <- 80 # Corte del numero de muestras en las que aparecera mi taxa 
		if (length_clase > length_clase_en_curso){
			corte <- round(length_clase_en_curso*cut/100)
		} else {
			corte <- round(length_clase*cut/100)
		}
		MRexp <- filterData(MRexp, present = corte, depth = 1)
		MRexp <-cumNorm(MRexp, p = cumNormStatFast(MRexp))
		s <- normFactors(MRexp)
		mod= model.matrix(~1+ clase, data = pData(MRexp)) # clase es el nombre de la columna 2 de mis metadatos
		fit_alif = fitFeatureModel(MRexp, mod)
		coeficientes <- MRcoefs(fit_alif, number = 50) # Numero de muestras que voy a obtener 
		exportMat(as.matrix(coeficientes), file=paste(clase,"_", clase_en_turno,"_OTUS_diff.txt", sep=""))
		print(paste("Ya hice el par ", clase,"-", clase_en_turno, sep=""))
	}
	print("Listo! Ya termine, busca tus tablas")
}

dir()

# Juntar todos los resultados de OTUS_diff.txt
path <- getwd()
directorio <- paste(path, list.files(path, "*"), sep="/")

# Extraer solo las tablas de OTUS_diff.txt del objeto directorio
directorio <- directorio[grep("OTUS_diff.txt", directorio)]

# Sacar el numero de combinaciones
combinaciones <- combinations(length(unique(muestras$clase)), 2)
combinaciones

directorio <- directorio[c(1,2,4)]

# Unir las tablas de las combinaciones
all_tablas <- data.frame()
for (i in 1:length(directorio)){
	tabla <- read.delim(directorio[i], header=T)
	file <- strsplit(directorio[i], "/")[[1]][length(strsplit(directorio[i], "/")[[1]])]
	pairs <- strsplit(file, "_OTUS")[[1]][1]
	tabla$pair <- pairs
	all_tablas <- rbind(all_tablas, tabla)
}

View(all_tablas)

# Escribir tabla de todos los resultados
write.table(all_tablas, "concat_results_OTUS_diff.txt", col.names=T, row.names=F, quote=F, sep="\t")

# Generar un filtro de p ajustado a < 0.01 y <0.05
length(which(all_tablas$adjPvalues<0.01))
length(which(all_tablas$adjPvalues<0.05))

filtered <- all_tablas[which(all_tablas$adjPvalues<0.05),]
dim(filtered)
filtered_01 <- all_tablas[which(all_tablas$adjPvalues<0.01),]
dim(filtered_01)

write.table(filtered, "filtered_results_OTUS_diff_padj0.05.txt", col.names=T, row.names=F, quote=F, sep="\t")
write.table(filtered_01, "filtered_results_OTUS_diff_padj0.01.txt", col.names=T, row.names=F, quote=F, sep="\t")

generos_filtered <- table(filtered_01$Taxa.and.Samples)
generos_interes <- names(generos_filtered[which(generos_filtered==3)])

# generar tabla de logfold change
table_fold <- filtered_01[which(filtered_01$Taxa.and.Samples%in%generos_interes),c(1,2,6)]

# Extraer la informacion de la frecuencia relativa de los generos
abund_tabla <- read.delim("../percent_Genus.txt", header=T, row.names=1) 

abund_tabla_interes <- abund_tabla[which(rownames(abund_tabla)%in% generos_interes),]

# Generar una tabla de las medias de cada grupo de los generos de interes
tabla_medias <- matrix(nrow=dim(abund_tabla_interes)[1], ncol=length(grupos)*2)

rownames(tabla_medias) <- rownames(abund_tabla_interes)
colnames(tabla_medias) <- c(grupos, paste(grupos, "_DE", sep=""))

# Generar medias y DE para cada genero
for (i in 1:dim(tabla_medias)[1]){
	for (j in 1:length(grupos)){
		ind <- which(muestras$clase== grupos[j])
		submatrix <- as.matrix(abund_tabla_interes[i,ind])
		tabla_medias[i,j] <- mean(submatrix) #media
		tabla_medias[i,j+length(grupos)]<- sd(submatrix) #DE
	}
}

View(tabla_medias)

# Escribir tabla
write.table(tabla_medias, "../tabla_medias_Genus_diff_abund.txt", col.names=T, row.names=T, sep="\t", quote=F)

# Generar plot de logFC
ggplot(table_fold, aes(x= Taxa.and.Samples, y= logFC, fill = pair)) +
	geom_bar(position=position_dodge(), width = 0.8, stat="identity") +
	theme_bw() + labs(x="Genus", y="logFC") + coord_flip() + scale_fill_manual(values = c("coral1", "seagreen2", "deepskyblue")) +
	theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), plot.title = element_text(color="black", size = 6, face="italic", hjust = 0.5), legend.position="bottom")

# Guardar imagen
png("../../figuras/logFC_Genus.png", width = 8*300, height = 5*300, res = 300, pointsize = 8, units= "px")
ggplot(table_fold, aes(x= Taxa.and.Samples, y= logFC, fill = pair)) +
	geom_bar(position=position_dodge(), width = 0.8, stat="identity") +
	theme_bw() + labs(x="Genus", y="logFC") + coord_flip() + scale_fill_manual(values = c("coral1", "seagreen2", "deepskyblue")) +
	theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), plot.title = element_text(color="black", size = 6, face="italic", hjust = 0.5), legend.position="bottom")
dev.off()

######## 
ls()
sessionInfo()
