########################################################################
#########                       PASPE 2021                     #########
#########   Analisis de datos de Ciencias Genomicas usando R   #########   
######### E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)  #########
#########                 Bitacora de comandos 1               #########
#########          UNIDAD 1. Introduccion a Bioconductor       #########
#########           Sesion 1 y 2. Comandos basicos             #########
########################################################################

# Texto sin acentos

### ORGANIZACION DE ESPACIO DE TRABAJO

# En donde estamos parados
getwd()

# Posicionarme en donde quiero generar el directorio de trabajo
setwd("Cambiar a la ruta del directorio de trabajo")

# Crear directorio "PASPE_2020_Datos_genomicos_R"
system("mkdir PASPE_2020_Datos_genomicos_R")

# Entrar al directorio "PASPE_2020_Datos_genomicos_R"
setwd("PASPE_2020_Datos_genomicos_R")

### Ejercicio 1. Instalacion de librerias de Bioconductor

if (!requireNamespace("BiocManager", quietly = TRUE))
install.packages("BiocManager")

# Instalacion de "GenomicRanges"
BiocManager::install("GenomicRanges")


### Ejercicio 2. Instalacion de librerias de CRAN

install.packages("vegan", dependencies=T)

### Ejercicio 3. Variables

variable_caracter <- "Caracteres"
variable_caracter
variable_numerica <- 1029
variable_numerica
variable_logica <- TRUE
variable_logica

# Determinar la clase de mis variables
class(variable_caracter)
class(variable_numerica)
class(variable_logica)

### Ejercicio 4. Operaciones basicas

# Generacion de objetos
x <- seq (1,10,1)
y <- rep (2,10)

# Exploracion de las dimenciones de mis objetos
length(x)
length(y)

# Operaciones basicas
suma <- x + y
suma
multiplicacion <- x * y
multiplicacion
resta <- x - y
resta
division <- x/y 
division

# Adicionar mas de un caracter o un numero a mi variable
numeros <- c(10,22,30)
numeros
letras <- c("A", "B", "C")
letras
ambos <- c("A", 15, "B", 30)
ambos
ambos <- c(15, "A", 30, "B")
ambos

# Pegado de textos
texto <- c (rep ("gen",5), rep ("protein",5))
paste (texto, x, sep="-")


### Ejercicio 5. Data input

# Leer tabla "abiotic_variables.txt"
variables <- read.delim("tablas/abiotic_variables.txt", header=T)

# Observar la tabla
View(variables)

# Leer tabla "abiotic_variables.txt" y que los nombres de las filas sean el identificador de la muestra
variables <- read.delim("tablas/abiotic_variables.txt", header=T, row.names=1)

# Explorar la tabla variables

head(variables)
dim(variables)
summary(variables)

### Ejercicio 6. Acceder a los elementos de la tabla
dim(variables)

# Columnas
# una sola columna
variables[,3]
variables$Total_Co

# Dos o mas columnas seguidas
variables[,1:3]

# Dos o mas columnas en desorden 
variables[,c(2,5,6,1)]

# Filas
# una sola fila
variables[1,]

# Dos o mas filas seguidas
variables[3:6,]

# Dos o mas columnas en desorden 
variables[c(12,6,1),]

# Con un valor especifico con los nombres de las columnas o filas
# una sola variable columnas
which(colnames(variables)=="Heneicosane")
variables[,which(colnames(variables)=="Heneicosane")]

# dos o mas variables
variables_interes <- c("Heneicosane", "Total_Ba", "Hexacosane")
which(colnames(variables) %in% variables_interes)
variables[,which(colnames(variables) %in% variables_interes)]

# una sola variable filas
which(rownames(variables)=="Someras_S2")
variables[which(rownames(variables)=="Someras_S2"),]

# dos o mas variables
variables_interes <- c("Costa_S1", "Costa_S2", "Profundas_S4")
which(rownames(variables) %in% variables_interes)
variables[which(rownames(variables) %in% variables_interes),]

# con un rango determinado de valores
summary(variables$Phenanthrene)
# Obtener el valor
variables$Phenanthrene[which(variables$Phenanthrene>7)]
# Obtener el nombre de la estacion
rownames(variables)[which(variables$Phenanthrene>7)]
variables[which(variables$Phenanthrene>7),17:18]


### Ejercicio 7. Adicion de columnas y filas a tablas
# Crear un objetos con una variable extra

extra_columna <- data.frame(Col_extra = c(rnorm(5, 31.8762, 0.233), rnorm(5, 41.6213, 0.278), rnorm(5, 11.4534, 0.3123)))
extra_fila <- data.frame(variables[2,]+2)

# Cambiar nombre de la fila
rownames(extra_fila) <- "Fila_extra"

# unir las columnas con cbind
tabla_con_columna_extra <- cbind(variables, extra_columna)

# unir las filas con rbind
tabla_con_fila_extra <- rbind(extra_fila,variables)


### Ejercicio 8. Generacion de matrices
# generar una matrix vacia
nueva_tabla <- matrix(nrow=15, ncol=35)

# generar una matrix con datos
nueva_tabla <- matrix(data=0, nrow=15, ncol=35)

# Cambiar nombres de columnas y filas

colnames(nueva_tabla) <- colnames(variables)
rownames(nueva_tabla) <- rownames(variables)

### Ejercicio 9. Escritura de datos
# texto delimitado por tabuladores
write.table(nueva_tabla, "tablas/tabla_vacia.txt", sep="\t", quote=FALSE, row.names= TRUE, col.names= TRUE)
# texto delimitado por comas
write.csv(nueva_tabla, "tablas/tabla_vacia.csv", quote=FALSE, row.names=TRUE)
# Listar archivos de un directorio

dir ("tablas/")

### Ejercicio 10. Estructuras de control
# Ciclos FOR
as.data.frame(colnames(variables))
HC_alifaticos <- colnames(variables)[1:13]
HC_aromaticos <- colnames(variables)[14:21]

nueva_tabla <- matrix(ncol=4, nrow=dim(variables)[1])
head(nueva_tabla)
colnames(nueva_tabla) <- c("HC_alifaticos_totales", "HC_aromaticos_totales", "Organic_Matter", "Deep")
rownames(nueva_tabla) <- rownames(variables)

num_alif <- which(colnames(variables)%in%HC_alifaticos)
num_arom <- which(colnames(variables)%in% HC_aromaticos)


for (i in 1:dim(nueva_tabla)[1]){
	nueva_tabla[i,1] <- rowSums(variables[i,num_alif])
	nueva_tabla[i,2] <- rowSums(variables[i,num_arom])
	nueva_tabla[i,3] <- variables[i, which(colnames(variables)=="Organic_Matter")]
	nueva_tabla[i,4] <- variables[i, which(colnames(variables)=="Deep")]
}

head(nueva_tabla)


# if and else
if (10>50) {
	print("Verdadero")
} else {
	print ("Falso")
}

# ifelse 
num <- 1:10
ifelse(num %% 2 == 0, "Par", "Non")

# ifelse para decodificar variables
num <- c(1,0,0,0,0,0,1,1,0,1,1,0)
num <- ifelse(num == 0, "Hombre", "Mujer")
num

# while
count <- 0
while (count < 10){
	print(count)
	count <- count +1
}

### Ejercicio 11. Familia apply --> sapply
class(nueva_tabla)
nueva_tabla <- as.data.frame(nueva_tabla)
nueva_tabla$Clase <-sapply(as.character(rownames(nueva_tabla)), function(x){strsplit(x, "_")[[1]][1]}) 

head(nueva_tabla)
View(nueva_tabla)
summary(nueva_tabla)
nueva_tabla$Clase <- as.factor(nueva_tabla$Clase)
summary(nueva_tabla)

### Ejercicio 12. Listado de variables e Informacion de la sesion
ls()
sessionInfo()